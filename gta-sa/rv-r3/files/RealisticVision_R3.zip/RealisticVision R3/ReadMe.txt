RealisticVision R3
a RenderHook preset by SunseT
https://www.youtube.com/AbiYasidAlMajid
RenderHook Discord Server: https://discord.gg/rsZEUNW

[Changelog]
- Added Cloudworks by RTU
- New timecyc settings with corrected interior lighting
- Improved rainy weather with dynamic reflection when using materials
- Dynamic volumetric lighting in different wheaters
- And much more

[Complete Guide]
https://youtu.be/lKTlgn6SrfQ

[Install]
1. If you have Steam or Rockstar Launcher version, downgrade it to 1.0
https://gtaforums.com/topic/927016-san-andreas-downgrader
2. Backup "timecyc.dat" file inside data folder in GTA SA directory, Backup the whole game data if necessary
3. Install Viz's Essential Pack
https://vizrak.github.io/RHEssentials
4. Choose High or Low settings, then put all files inside "High Settings" or "Low Settings" to your gta sa folder
5. (Optional) Put "RealisticVision R3.ini" inside "Bloom and Lens Flare" then "For High Settings" or "For Low Settings" to GTA SA folder, to add bloom and lens flare effect (not recommended for enabled HUD)
6. Install ReShade shader files
   - Download ReShade Setup from here: https://reshade.me
   - Open ReShade setup
   - Select your gta_sa.exe, then click next
   - Select Microsoft DirectX 10/11/12, then click next
   - In the bottom section, browse "RealisticVision R3.ini", then click next
   - When its done, click finish
7. If the game crashed after splash screen, try renaming "dxgi.dll" file to "d3d11.dll"
8. If you have PBR materials, put "materials" folder inside GTA SA directory
9. If you in windowed mode, press Alt + Enter to change to fullscreen mode
10. In the game, set Draw Distance to max

[Additional Step]
If you already installed the mod but without Bloom and Lens Flare effects but want to add them
1. After quit the game, do step number 5 above
2. Then do step number 6 but after selecting rendering API (DirectX 10/11/12), select update ReShade and effects
3. The rest step are the same as before

[Uninstall]
1. Delete all file that you install before
2. Put back backup file "timecyc.dat" into data folder in GTA SA directory

[Note]
- If this mod read as a virus, don't worry and just ignore it because it's a false positive
- RenderHook is an unstable mod, maybe you will find bugs that will be annoying in certain places, and there are also some missions that are not suitable for playthrough. For examples, "Amphibious Assault" mission make the game crash in the middle of the mission, light particles in "Amphibious Assault" and "Black Project" missions that don't appear, and thermal vision and night vision goggles that don't work as well as they should.

[RH incompatibilities]
https://docs.google.com/document/d/1kNHZj8onY9T9zav5U2Rwup5zO9ncmV8O_2EEufsF0lI/edit?usp=drivesdk

Thank You for Reading :D