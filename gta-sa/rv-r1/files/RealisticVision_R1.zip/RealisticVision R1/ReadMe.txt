RealisticVision R1
a RenderHook preset by SunseT
https://www.youtube.com/AbiYasidAlMajid
RenderHook Discord Server: https://discord.gg/rsZEUNW

[Complete Guide]
https://youtu.be/lKTlgn6SrfQ
This guide have similar method despite for RealisticVision R3

[Install]
1. If you have Steam or Rockstar Launcher version, downgrade it to 1.0
https://gtaforums.com/topic/927016-san-andreas-downgrader
2. Backup "timecyc.dat" file inside data folder in GTA SA directory, Backup the whole game data if necessary
3. Install Viz's Essential Pack
https://vizrak.github.io/RHEssentials
4. Put all files inside "Put to SA Folder" to your GTA SA directory
5. Install ReShade shader files
   - Download ReShade Setup from here: https://reshade.me
   - Open ReShade setup
   - Select your gta_sa.exe, then click next
   - Select Microsoft DirectX 10/11/12, then click next
   - In the bottom section, browse "RealisticVision R1.ini", then click next
   - When its done, click finish
6. If the game crashed after splash screen, try renaming "dxgi.dll" file to "d3d11.dll"
7. If you have PBR materials, put "materials" folder inside GTA SA directory
8. If you in windowed mode, press Alt + Enter to change to fullscreen mode
9. In the game, set Draw Distance to max

[Uninstall]
1. Delete all file that you install before
2. Put back backup file "timecyc.dat" into data folder in GTA SA directory

[Note]
- If this mod read as a virus, don't worry and just ignore it because it's a false positive
- RenderHook is an unstable mod, maybe you will find bugs that will be annoying in certain places, and there are also some missions that are not suitable for playthrough. For examples, "Amphibious Assault" mission make the game crash in the middle of the mission, light particles in "Amphibious Assault" and "Black Project" missions that don't appear, and thermal vision and night vision goggles that don't work as well as they should.

[RH incompatibilities]
https://docs.google.com/document/d/1kNHZj8onY9T9zav5U2Rwup5zO9ncmV8O_2EEufsF0lI/edit?usp=drivesdk

Thank You for Reading :D